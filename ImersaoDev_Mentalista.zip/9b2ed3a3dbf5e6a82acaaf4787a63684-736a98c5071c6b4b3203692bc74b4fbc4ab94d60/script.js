var numSecreto = parseInt(Math.random() * 10)

var chances =  5

var nome = prompt("Informe seu primeiro nome")

while(chances>0)
  {
  var chute = parseInt(prompt("Informe um número de 0 a 10"))
  
  if(chute > numSecreto) {
    
  console.log(nome+","+" o número secreto é: "+numSecreto+",  seu chute foi menor = "+chute)
    chances--
    console.log("Número de chances: "+chances)
    alert(nome + ", seu chute foi: "+chute+" e o número secreto é menor!\nSuas chances: "+chances)
    if(chances<=0){
      alert('Suas chances acabaram!')
    }
    
  } else if(chute < numSecreto){
     console.log(nome+","+" O número secreto é: "+numSecreto+",  seu chute foi menor = "+chute)
    chances --
    console.log("Número de chances: "+chances)
    alert(nome + ", seu chute foi: "+chute+" e o número secreto é maior!\nSuas chances: "+chances)
    if(chances<=0){
      alert('Suas chances acabaram!')
    }
  }
  
  else if(chute == numSecreto){
     console.log("Acertou! O número secreto é: "+chute)
    chances = chances
    console.log("Número de chances: "+chances)
    alert("Parabéns!\n O número secreto é: "+chute)
    break;
  }
  
}



